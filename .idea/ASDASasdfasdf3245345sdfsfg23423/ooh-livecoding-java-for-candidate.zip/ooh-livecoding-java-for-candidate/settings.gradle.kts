rootProject.name = "ooh-livecoding-java"
