# ooh-livecoding-java

** This README.md is prepared for candidates! **

A Spring Boot REST API for managing Parcel Machines, exposing endpoints to retrieve machines near a given GPS location and to create new ones.

> This project was generated with [Claude Code](https://claude.ai/claude-code) for recruiting purposes.

---

## Prerequisites

| Requirement | Version |
|---|---|
| JDK | 25 |
| Gradle | 9.4.0 (via wrapper) |
| IDE | IntelliJ IDEA (recommended) or any IDE with Gradle support |

Ensure `JAVA_HOME` points to a JDK 25 installation before building or running the project.

---

## Importing into IntelliJ IDEA

1. Open IntelliJ IDEA.
2. Select **File → Open** and navigate to the `ooh-livecoding-java` directory.
3. IntelliJ will detect the Gradle build file and prompt to import — select **Open as Project**.
4. In the **Gradle** tool window, confirm the Gradle JVM is set to JDK 25 (**Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JVM**).
5. Wait for Gradle sync to complete and indexing to finish.

### Verifying Source Directories

Gradle sync configures source directories automatically. If they are not picked up correctly, verify or set them manually via **File → Project Structure → Modules → Sources tab**:

| Directory | Mark as |
|---|---|
| `src/main/java` | Sources Root |
| `src/main/resources` | Resources Root |
| `src/test/java` | Test Sources Root |
| `src/test/resources` | Test Resources Root |

Alternatively, right-click any directory in the Project view and select **Mark Directory as** to assign the appropriate root type.

---

## Building the Project

Using the Gradle wrapper from the project root:

```bash
./gradlew build
```

To build without running tests:

```bash
./gradlew build -x test
```

---

## Running the Application

```bash
./gradlew bootRun
```

The application starts on port `8080` by default.

---

## API

### Get Parcel Machines Near Location

```
GET /parcel-machines?latitude={lat}&longitude={lon}&radius={radius}
```

| Parameter | Type | Description |
|---|---|---|
| `latitude` | `double` | Requester's GPS latitude |
| `longitude` | `double` | Requester's GPS longitude |
| `radius` | `double` | Search radius in metres |

**Example request:**

```bash
curl "http://localhost:8080/parcel-machines?latitude=52.2297&longitude=21.0122&radius=5000"
```

**Example response:**

```json
[
  {
    "id": "KRK-001",
    "name": "Rynek Główny",
    "location": {
      "latitude": 50.0614,
      "longitude": 19.9372
    },
    "createdAt": "1970-01-01T00:00:00Z"
  },
  {
    "id": "KRK-002",
    "name": "Bazylika Mariacka",
    "location": {
      "latitude": 50.0617,
      "longitude": 19.9394
    },
    "createdAt": "1970-01-01T00:00:00Z"
  },
  {
    "id": "KRK-003",
    "name": "Plac Wszystkich Świętych",
    "location": {
      "latitude": 50.0591,
      "longitude": 19.934
    },
    "createdAt": "1970-01-01T00:00:00Z"
  },
  {
    "id": "KRK-004",
    "name": "Teatr Słowackiego",
    "location": {
      "latitude": 50.0653,
      "longitude": 19.9418
    },
    "createdAt": "1970-01-01T00:00:00Z"
  },
  {
    "id": "KRK-005",
    "name": "Wawel",
    "location": {
      "latitude": 50.0541,
      "longitude": 19.9352
    },
    "createdAt": "1970-01-01T00:00:00Z"
  }
]
```

> The repository implementation is a hardcoded in-memory stub returning 5 parcel machines located near Kraków's Main Market Square.

---

## Running Tests

Execute the full test suite:

```bash
./gradlew test
```

Integration tests use `@SpringBootTest` with `WebEnvironment.RANDOM_PORT`, starting a real embedded server and issuing actual HTTP requests via `TestRestTemplate`.

Test reports are generated at:

```
build/reports/tests/test/index.html
```

---

## Architecture

The project follows **Hexagonal Architecture** (Ports and Adapters), which enforces a strict separation between business logic and infrastructure concerns. The domain has no dependency on any framework. Spring annotations are confined to the adapter and application layers.

The dependency rule is unidirectional: adapters depend on ports, ports belong to the domain, and the domain depends on nothing external.

```
                    ┌─────────────────────────────┐
                    │           Domain            │
                    │  (pure Java, no framework)  │
                    └──────────────┬──────────────┘
                                   │ defines
                    ┌──────────────▼──────────────┐
                    │            Ports            │
                    │  (inbound & outbound interfaces) │
                    └──────┬───────────────┬──────┘
                           │               │
              implements   │               │   implements
         ┌─────────────────▼──┐       ┌───▼─────────────────┐
         │  Inbound Adapters  │       │  Outbound Adapters  │
         │  (REST controllers)│       │  (repositories)     │
         └────────────────────┘       └─────────────────────┘
```

## Project Structure

```
src/
├── main/
│   ├── java/pl/inpost/ooh/livecoding/
│   │   ├── LivecodingApplication.java
│   │   └── parcelmachine/
│   │       ├── domain/
│   │       │   └── model/
│   │       │       ├── GeoLocation.java                                  ← value object representing GPS coordinates
│   │       │       ├── ParcelMachine.java                                ← core domain entity
│   │       │       └── ParcelMachineOutOfKrakowBoundsException.java      ← thrown when location is outside Kraków
│   │       ├── port/
│   │       │   ├── inbound/
│   │       │   │   ├── FindNearbyParcelMachinesUseCase.java              ← defines the nearby search use case
│   │       │   │   ├── FindDoubleInspectedParcelMachinesUseCase.java     ← defines the inspection use case
│   │       │   │   └── HandleParcelMachineUnavailabilityUseCase.java     ← defines the unavailability handling use case
│   │       │   └── outbound/
│   │       │       ├── ParcelMachineCreatedPublisher.java                ← defines event publishing contract
│   │       │       └── ParcelMachineRepository.java                      ← defines persistence contract
│   │       ├── application/
│   │       │   ├── HandleParcelMachineUnavailabilityService.java         ← orchestrates unavailability handling use case
│   │       │   └── InspectionService.java                                ← orchestrates inspection use case
│   │       └── adapter/
│   │           ├── inbound/
│   │           │   ├── kafka/
│   │           │   │   └── ParcelMachineUnavailableMessage.java          ← Kafka message record
│   │           │   └── rest/
│   │           │       └── ParcelMachineController.java                  ← translates HTTP to use case calls
│   │           └── outbound/
│   │               ├── inmemory/
│   │               │   └── InMemoryParcelMachineRepository.java          ← in-memory stub implementation
│   │               └── kafka/
│   │                   └── ParcelMachineCreatedMessage.java              ← Kafka message record
│   └── resources/
│       └── application.yml
└── test/java/pl/inpost/ooh/livecoding/
    └── parcelmachine/
        ├── adapter/
        │   ├── inbound/rest/
        │   │   ├── ParcelMachineControllerIT.java
        │   │   └── ParcelMachineTestConfiguration.java                   ← wires FakeParcelMachineRepository for tests
        │   └── outbound/fake/
        │       └── FakeParcelMachineRepository.java                      ← configurable test double
        └── application/
            └── InspectionServiceTest.java
```

## Tasks
You can choose two implementation tasks, except the algorithmic one, and use AI tools to speed-up implementation. If you are doing so, please be transparent about it. You should share what tool you are using, prompts etc.

1. Build the project and ensure all tests are passing.

2. Open controller and identify what need to be refactored.

3. Ensure appropriate test coverage.

4. Parcel machines are identified using numbers from 1 to N. Servicemen are identified with string ids.
    Servicemen visit parcel machines for inspection. All N parcel machines should be inspected, however it may happen
    that some are visited by two servicemen and some are not visited at all.
    1. Variant one
       We accept an array with parcel machines ids that were inspected by a serviceman. Find all double-inspected machines. Implement your solution in the InspectionService present it, addressing computational (time) complexity and memory (space) complexity. 
    2. Variant two
       Our system gets two arrays with inspection data:
        1. first array contains parcel machine ids.
        2. second array contains serviceman ids.
    
        First parcel machine in the first array was inspected by the first serviceman in the second array etc.
        Identify all machines that were inspected twice and by which serviceman. Showcase your solution works fine.
        Estimate computational and space complexities.
    
        Sample intput: [1 , 2 , 1], ["a", "b", "c"]

        Sample output: {1-> ["a", "b"]} of type ```Map<Int, List<String>>```.

5. Add new endpoint to create new parcel machine.
   1. Require the same set of attributes that are returned by the GET endpoint. Additionally, add createdAt field.
   2. Validate that new parcel machine is within Kraków boundaries (for simplicity we only want to check that 49.97N <= latitude <= 50.18N; 19.79E <= longitude <= 20.22E).
   3. Test that correct createdAt is saved in the DB.
6. Kafka
   1. Discuss Kafka producer and consumer configuration using Spring boot.
   2. Implement or discuss concurrent KafkaListener.
   3. Implement or discuss KafkaProducer.
   4. Discuss poison pill and DLQ.
   5. At least-once vs exactly-once.
7. Extend the endpoint that creates a new parcel machine to publish a message that a new parcel machine was created to Kafka.
8. AI-literacy.
