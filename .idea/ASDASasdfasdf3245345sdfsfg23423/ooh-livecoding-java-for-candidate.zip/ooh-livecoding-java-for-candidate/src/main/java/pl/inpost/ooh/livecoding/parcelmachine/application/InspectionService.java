package pl.inpost.ooh.livecoding.parcelmachine.application;

import pl.inpost.ooh.livecoding.parcelmachine.port.inbound.FindDoubleInspectedParcelMachinesUseCase;

import java.util.*;

public class InspectionService implements FindDoubleInspectedParcelMachinesUseCase {

    @Override
    public List<Integer> findDoubleInspected(int[] parcelMachineIds) {
        // candidate solution for variant 1 here
        return null;
    }

    @Override
    public Map<Integer, List<String>> findDoubleInspectedWithDetails(int[] parcelMachineIds, String[] servicemanIds) {
        // candidate solution for variant 2 here
        return null;
    }
}
