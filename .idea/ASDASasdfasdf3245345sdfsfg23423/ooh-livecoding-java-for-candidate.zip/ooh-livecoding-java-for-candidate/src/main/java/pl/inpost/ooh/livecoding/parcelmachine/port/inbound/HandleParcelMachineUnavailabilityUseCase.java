package pl.inpost.ooh.livecoding.parcelmachine.port.inbound;

public interface HandleParcelMachineUnavailabilityUseCase {
    void handle(int parcelMachineId);
}
