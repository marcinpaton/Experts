package pl.inpost.ooh.livecoding.parcelmachine.adapter.inbound.rest;

import org.springframework.web.bind.annotation.*;
import pl.inpost.ooh.livecoding.parcelmachine.adapter.outbound.inmemory.InMemoryParcelMachineRepository;
import pl.inpost.ooh.livecoding.parcelmachine.domain.model.GeoLocation;
import pl.inpost.ooh.livecoding.parcelmachine.domain.model.ParcelMachine;
import pl.inpost.ooh.livecoding.parcelmachine.port.outbound.ParcelMachineRepository;

import java.util.List;

@RestController
@RequestMapping("/parcel-machines")
class ParcelMachineController {

    ParcelMachineRepository repository = new InMemoryParcelMachineRepository();

    @GetMapping
    List<ParcelMachine> getNearby(
            @RequestParam double latitude,
            @RequestParam double longitude,
            @RequestParam double radius) {
        return repository.findAllNearby(new GeoLocation(latitude, longitude), radius);
    }

}
