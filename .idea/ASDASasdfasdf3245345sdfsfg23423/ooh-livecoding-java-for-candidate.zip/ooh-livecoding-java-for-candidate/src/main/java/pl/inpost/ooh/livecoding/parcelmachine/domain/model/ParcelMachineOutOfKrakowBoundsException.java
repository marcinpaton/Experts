package pl.inpost.ooh.livecoding.parcelmachine.domain.model;

public class ParcelMachineOutOfKrakowBoundsException extends RuntimeException {
    public ParcelMachineOutOfKrakowBoundsException(GeoLocation location) {
        super("Location %s is outside Kraków boundaries".formatted(location));
    }
}
