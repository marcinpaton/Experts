package pl.inpost.ooh.livecoding.parcelmachine.port.inbound;

import java.util.List;
import java.util.Map;

public interface FindDoubleInspectedParcelMachinesUseCase {

    List<Integer> findDoubleInspected(int[] parcelMachineIds);

    Map<Integer, List<String>> findDoubleInspectedWithDetails(int[] parcelMachineIds, String[] servicemanIds);
}
