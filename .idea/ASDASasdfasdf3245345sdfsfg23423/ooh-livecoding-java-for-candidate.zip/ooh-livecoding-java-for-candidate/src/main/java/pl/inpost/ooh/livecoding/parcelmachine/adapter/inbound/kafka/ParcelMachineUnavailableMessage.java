package pl.inpost.ooh.livecoding.parcelmachine.adapter.inbound.kafka;

record ParcelMachineUnavailableMessage(int parcelMachineId) {}
