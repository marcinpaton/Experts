package pl.inpost.ooh.livecoding.parcelmachine.domain.model;

public record ParcelMachine(String id, String name, GeoLocation location, java.time.Instant createdAt) {}
