package pl.inpost.ooh.livecoding.parcelmachine.domain.model;

public record GeoLocation(double latitude, double longitude) {}
