package pl.inpost.ooh.livecoding.parcelmachine.adapter.outbound.inmemory;

import org.springframework.stereotype.Repository;
import pl.inpost.ooh.livecoding.parcelmachine.domain.model.GeoLocation;
import pl.inpost.ooh.livecoding.parcelmachine.domain.model.ParcelMachine;
import pl.inpost.ooh.livecoding.parcelmachine.port.outbound.ParcelMachineRepository;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Repository
public class InMemoryParcelMachineRepository implements ParcelMachineRepository {

    private final List<ParcelMachine> parcelMachines = new ArrayList<>(List.of(
            new ParcelMachine("KRK-001", "Rynek Główny",              new GeoLocation(50.0614, 19.9372), Instant.EPOCH),
            new ParcelMachine("KRK-002", "Bazylika Mariacka",         new GeoLocation(50.0617, 19.9394), Instant.EPOCH),
            new ParcelMachine("KRK-003", "Plac Wszystkich Świętych",  new GeoLocation(50.0591, 19.9340), Instant.EPOCH),
            new ParcelMachine("KRK-004", "Teatr Słowackiego",         new GeoLocation(50.0653, 19.9418), Instant.EPOCH),
            new ParcelMachine("KRK-005", "Wawel",                     new GeoLocation(50.0541, 19.9352), Instant.EPOCH)
    ));

    @Override
    public List<ParcelMachine> findAllNearby(GeoLocation location, double radiusMeters) {
        return List.copyOf(parcelMachines);
    }

    @Override
    public void save(ParcelMachine parcelMachine) {
        parcelMachines.add(parcelMachine);
    }
}
