package pl.inpost.ooh.livecoding.parcelmachine.port.outbound;

import pl.inpost.ooh.livecoding.parcelmachine.domain.model.GeoLocation;
import pl.inpost.ooh.livecoding.parcelmachine.domain.model.ParcelMachine;

import java.util.List;

public interface ParcelMachineRepository {

    List<ParcelMachine> findAllNearby(GeoLocation location, double radiusMeters);

    void save(ParcelMachine parcelMachine);
}
