package pl.inpost.ooh.livecoding.parcelmachine.adapter.outbound.kafka;

import java.time.Instant;

record ParcelMachineCreatedMessage(String parcelMachineId, Instant createdAt) {}
