package pl.inpost.ooh.livecoding.parcelmachine.port.outbound;

import java.time.Instant;

public interface ParcelMachineCreatedPublisher {
    void publish(String parcelMachineId, Instant createdAt);
}
