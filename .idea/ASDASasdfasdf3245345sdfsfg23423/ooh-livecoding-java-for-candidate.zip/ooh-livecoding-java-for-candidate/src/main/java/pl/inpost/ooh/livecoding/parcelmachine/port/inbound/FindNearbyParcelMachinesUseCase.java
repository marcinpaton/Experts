package pl.inpost.ooh.livecoding.parcelmachine.port.inbound;

import pl.inpost.ooh.livecoding.parcelmachine.domain.model.GeoLocation;
import pl.inpost.ooh.livecoding.parcelmachine.domain.model.ParcelMachine;

import java.util.List;

public interface FindNearbyParcelMachinesUseCase {

    List<ParcelMachine> findNearby(GeoLocation location, double radiusMeters);
}
