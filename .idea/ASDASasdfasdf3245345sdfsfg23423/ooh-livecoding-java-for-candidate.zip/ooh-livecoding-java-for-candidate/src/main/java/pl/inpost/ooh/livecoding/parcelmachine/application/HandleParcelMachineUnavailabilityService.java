package pl.inpost.ooh.livecoding.parcelmachine.application;

import org.springframework.stereotype.Service;
import pl.inpost.ooh.livecoding.parcelmachine.port.inbound.HandleParcelMachineUnavailabilityUseCase;

@Service
class HandleParcelMachineUnavailabilityService implements HandleParcelMachineUnavailabilityUseCase {

    @Override
    public void handle(int parcelMachineId) {
        // TODO: implement unavailability handling
    }
}
