package pl.inpost.ooh.livecoding.parcelmachine.adapter.outbound.fake;

import pl.inpost.ooh.livecoding.parcelmachine.domain.model.GeoLocation;
import pl.inpost.ooh.livecoding.parcelmachine.domain.model.ParcelMachine;
import pl.inpost.ooh.livecoding.parcelmachine.port.outbound.ParcelMachineRepository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FakeParcelMachineRepository implements ParcelMachineRepository {

    private final List<ParcelMachine> store = new ArrayList<>();

    public void save(ParcelMachine parcelMachine) {
        store.add(parcelMachine);
    }

    public void clear() {
        store.clear();
    }

    public List<ParcelMachine> findAll() {
        return Collections.unmodifiableList(store);
    }

    @Override
    public List<ParcelMachine> findAllNearby(GeoLocation location, double radiusMeters) {
        return Collections.unmodifiableList(store);
    }
}
