package pl.inpost.ooh.livecoding.parcelmachine.adapter.inbound.rest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import pl.inpost.ooh.livecoding.parcelmachine.adapter.outbound.fake.FakeParcelMachineRepository;
import pl.inpost.ooh.livecoding.parcelmachine.domain.model.GeoLocation;
import pl.inpost.ooh.livecoding.parcelmachine.domain.model.ParcelMachine;

import java.time.Instant;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Import(ParcelMachineTestConfiguration.class)
class ParcelMachineControllerIT {

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private FakeParcelMachineRepository repository;

    @BeforeEach
    void setUp() {
        repository.clear();
    }

    /*
        We expect the candidate to add relevant test cases based on the one provided below.
     */


    @Test
    void shouldReturnParcelMachinesNearGivenLocation() {
        repository.save(new ParcelMachine("TEST-001", "Test Machine", new GeoLocation(52.2297, 21.0122), Instant.EPOCH));

        var response = restTemplate.getForEntity(
                "/parcel-machines?latitude=52.2297&longitude=21.0122&radius=5000",
                List.class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).hasSize(5);
    }
}
