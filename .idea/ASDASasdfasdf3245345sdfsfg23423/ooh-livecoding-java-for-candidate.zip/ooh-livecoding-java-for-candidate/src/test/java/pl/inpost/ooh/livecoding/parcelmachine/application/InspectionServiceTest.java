package pl.inpost.ooh.livecoding.parcelmachine.application;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class InspectionServiceTest {

    private final InspectionService service = new InspectionService();

    @Test
    void shouldReturnMachineInspectedTwice() {

    }
}
