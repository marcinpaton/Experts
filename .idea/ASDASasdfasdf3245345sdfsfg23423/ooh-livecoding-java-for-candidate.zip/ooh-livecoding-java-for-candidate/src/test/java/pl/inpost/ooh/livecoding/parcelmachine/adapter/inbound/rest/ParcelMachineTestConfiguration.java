package pl.inpost.ooh.livecoding.parcelmachine.adapter.inbound.rest;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import pl.inpost.ooh.livecoding.parcelmachine.adapter.outbound.fake.FakeParcelMachineRepository;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

@TestConfiguration
class ParcelMachineTestConfiguration {

    @Bean
    @Primary
    FakeParcelMachineRepository parcelMachineRepository() {
        return new FakeParcelMachineRepository();
    }

}
